export const dynamic = "force-dynamic";

export default function ExpiredPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <div className="w-full max-w-md rounded-2xl border p-6 shadow-sm text-center space-y-3">
        <h1 className="text-2xl font-semibold">Link unavailable</h1>
        <p className="text-sm text-gray-600">
          This LinkyLocks URL is invalid, expired, revoked, or has reached its maximum opens.
        </p>

        <div className="pt-2">
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-medium bg-black text-white"
          >
            Go Home
          </a>
        </div>
      </div>
    </main>
  );
}
